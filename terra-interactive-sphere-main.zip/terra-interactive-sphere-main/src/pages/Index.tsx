
import Earth3D from '../components/Earth3D';

const Index = () => {
  return (
    <div className="min-h-screen bg-black overflow-hidden relative">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 p-6">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-2 tracking-wide">
            Terra Interactive
          </h1>
          <p className="text-lg md:text-xl text-blue-200 opacity-80">
            Explore our beautiful planet in 3D
          </p>
        </div>
      </div>

      {/* Controls Info */}
      <div className="absolute bottom-6 left-6 z-10 text-white/70 text-sm">
        <div className="bg-black/30 backdrop-blur-sm rounded-lg p-4 border border-white/20">
          <p className="mb-1">🖱️ <strong>Left Click + Drag:</strong> Rotate Earth</p>
          <p className="mb-1">🔍 <strong>Mouse Wheel:</strong> Zoom In/Out</p>
          <p>✨ <strong>Auto Rotation:</strong> Release to spin</p>
        </div>
      </div>

      {/* Earth Component */}
      <Earth3D />

      {/* Atmospheric Overlay */}
      <div className="absolute inset-0 bg-gradient-radial from-transparent via-transparent to-black/50 pointer-events-none" />
      
      {/* Stars Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="stars"></div>
        <div className="stars2"></div>
        <div className="stars3"></div>
      </div>
    </div>
  );
};

export default Index;
