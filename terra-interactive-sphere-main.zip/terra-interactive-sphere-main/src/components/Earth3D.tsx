import React, { useEffect, useRef } from 'react';

// Declare THREE as a global variable for TypeScript
declare global {
  interface Window {
    THREE: any;
  }
}

const Earth3D = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<any>(null);
  const rendererRef = useRef<any>(null);
  const earthRef = useRef<any>(null);
  const atmosphereRef = useRef<any>(null);
  const cameraRef = useRef<any>(null);
  const isUserInteracting = useRef(false);
  const mousePos = useRef({ x: 0, y: 0 });
  const cleanupRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Check if THREE.js is already loaded
    if (window.THREE) {
      initializeEarth();
      return;
    }

    // Import Three.js dynamically
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    script.onload = () => {
      if (window.THREE) {
        initializeEarth();
      }
    };
    script.onerror = () => {
      console.error('Failed to load THREE.js');
    };
    document.head.appendChild(script);

    return () => {
      if (cleanupRef.current) {
        cleanupRef.current();
      }
      if (rendererRef.current && containerRef.current) {
        try {
          containerRef.current.removeChild(rendererRef.current.domElement);
        } catch (error) {
          console.warn('Failed to remove renderer element:', error);
        }
      }
      // Remove script tag
      const existingScript = document.querySelector('script[src*="three.min.js"]');
      if (existingScript && existingScript.parentNode) {
        existingScript.parentNode.removeChild(existingScript);
      }
    };
  }, []);

  const initializeEarth = () => {
    if (!containerRef.current || !window.THREE) return;

    const THREE = window.THREE;
    
    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.set(0, 0, 2.5);
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true, 
      alpha: true 
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    // Clear any existing canvas
    if (containerRef.current.firstChild) {
      containerRef.current.removeChild(containerRef.current.firstChild);
    }
    
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 0.5, 1);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Earth geometry and materials
    const earthGeometry = new THREE.SphereGeometry(1, 64, 64);

    // Create earth texture using canvas
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Create a simple earth-like texture
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, '#1e3a8a'); // Deep blue
    gradient.addColorStop(0.3, '#2563eb'); // Blue
    gradient.addColorStop(0.5, '#16a34a'); // Green
    gradient.addColorStop(0.7, '#22c55e'); // Light green
    gradient.addColorStop(1, '#1e3a8a'); // Back to blue

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add some continent-like shapes
    ctx.fillStyle = '#16a34a';
    for (let i = 0; i < 50; i++) {
      ctx.beginPath();
      ctx.arc(
        Math.random() * canvas.width,
        Math.random() * canvas.height,
        Math.random() * 50 + 20,
        0,
        Math.PI * 2
      );
      ctx.fill();
    }

    const earthTexture = new THREE.CanvasTexture(canvas);
    
    const earthMaterial = new THREE.MeshPhongMaterial({
      map: earthTexture,
      bumpScale: 0.05,
      specular: new THREE.Color(0x111111),
      shininess: 100
    });

    // Create Earth mesh
    const earth = new THREE.Mesh(earthGeometry, earthMaterial);
    earth.receiveShadow = true;
    earth.castShadow = true;
    scene.add(earth);
    earthRef.current = earth;

    // Atmosphere
    const atmosphereGeometry = new THREE.SphereGeometry(1.05, 64, 64);
    const atmosphereMaterial = new THREE.MeshPhongMaterial({
      color: 0x87ceeb,
      transparent: true,
      opacity: 0.3,
      side: THREE.DoubleSide
    });
    const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
    scene.add(atmosphere);
    atmosphereRef.current = atmosphere;

    // Add stars
    const starsGeometry = new THREE.BufferGeometry();
    const starsMaterial = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 1,
      sizeAttenuation: false
    });

    const starsVertices = [];
    for (let i = 0; i < 1000; i++) {
      const x = (Math.random() - 0.5) * 2000;
      const y = (Math.random() - 0.5) * 2000;
      const z = (Math.random() - 0.5) * 2000;
      starsVertices.push(x, y, z);
    }

    starsGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starsVertices, 3));
    const stars = new THREE.Points(starsGeometry, starsMaterial);
    scene.add(stars);

    // Mouse controls
    const handleMouseDown = (event: MouseEvent) => {
      isUserInteracting.current = true;
      mousePos.current.x = event.clientX;
      mousePos.current.y = event.clientY;
    };

    const handleMouseMove = (event: MouseEvent) => {
      if (!isUserInteracting.current || !earthRef.current || !atmosphereRef.current) return;

      const deltaX = event.clientX - mousePos.current.x;
      const deltaY = event.clientY - mousePos.current.y;

      earthRef.current.rotation.y += deltaX * 0.005;
      earthRef.current.rotation.x += deltaY * 0.005;
      atmosphereRef.current.rotation.y += deltaX * 0.005;
      atmosphereRef.current.rotation.x += deltaY * 0.005;

      mousePos.current.x = event.clientX;
      mousePos.current.y = event.clientY;
    };

    const handleMouseUp = () => {
      isUserInteracting.current = false;
    };

    // Touch controls for mobile
    const handleTouchStart = (event: TouchEvent) => {
      event.preventDefault();
      if (event.touches.length === 1) {
        isUserInteracting.current = true;
        mousePos.current.x = event.touches[0].clientX;
        mousePos.current.y = event.touches[0].clientY;
      }
    };

    const handleTouchMove = (event: TouchEvent) => {
      event.preventDefault();
      if (!isUserInteracting.current || !earthRef.current || !atmosphereRef.current) return;
      
      if (event.touches.length === 1) {
        const deltaX = event.touches[0].clientX - mousePos.current.x;
        const deltaY = event.touches[0].clientY - mousePos.current.y;

        earthRef.current.rotation.y += deltaX * 0.005;
        earthRef.current.rotation.x += deltaY * 0.005;
        atmosphereRef.current.rotation.y += deltaX * 0.005;
        atmosphereRef.current.rotation.x += deltaY * 0.005;

        mousePos.current.x = event.touches[0].clientX;
        mousePos.current.y = event.touches[0].clientY;
      }
    };

    const handleTouchEnd = (event: TouchEvent) => {
      event.preventDefault();
      isUserInteracting.current = false;
    };

    const handleWheel = (event: WheelEvent) => {
      if (!cameraRef.current) return;
      cameraRef.current.position.z += event.deltaY * 0.001;
      cameraRef.current.position.z = Math.max(1.5, Math.min(5, cameraRef.current.position.z));
    };

    // Event listeners for mouse
    renderer.domElement.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    renderer.domElement.addEventListener('wheel', handleWheel);

    // Event listeners for touch
    renderer.domElement.addEventListener('touchstart', handleTouchStart, { passive: false });
    renderer.domElement.addEventListener('touchmove', handleTouchMove, { passive: false });
    renderer.domElement.addEventListener('touchend', handleTouchEnd, { passive: false });

    // Handle window resize
    const handleResize = () => {
      if (!cameraRef.current || !rendererRef.current) return;
      cameraRef.current.aspect = window.innerWidth / window.innerHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation loop
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      // Auto rotation when not interacting
      if (!isUserInteracting.current && earthRef.current && atmosphereRef.current) {
        earthRef.current.rotation.y += 0.002;
        atmosphereRef.current.rotation.y += 0.001;
      }

      // Gentle atmosphere pulsing
      if (atmosphereRef.current) {
        atmosphereRef.current.material.opacity = 0.3 + Math.sin(Date.now() * 0.001) * 0.1;
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    animate();

    // Store cleanup function
    cleanupRef.current = () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
      renderer.domElement.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      renderer.domElement.removeEventListener('wheel', handleWheel);
      renderer.domElement.removeEventListener('touchstart', handleTouchStart);
      renderer.domElement.removeEventListener('touchmove', handleTouchMove);
      renderer.domElement.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('resize', handleResize);
    };
  };

  return (
    <div 
      ref={containerRef} 
      className="absolute inset-0 cursor-grab active:cursor-grabbing touch-none"
      style={{ zIndex: 1 }}
    />
  );
};

export default Earth3D;
